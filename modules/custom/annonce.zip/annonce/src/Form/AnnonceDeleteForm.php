<?php

namespace Drupal\annonce\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Annonce entities.
 *
 * @ingroup annonce
 */
class AnnonceDeleteForm extends ContentEntityDeleteForm {


}
